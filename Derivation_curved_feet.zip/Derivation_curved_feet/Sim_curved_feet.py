import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
from sympy import *
import dill

with open('equation.dill', 'rb') as file:
    equation = dill.load(file)
with open('Mass_mat.dill', 'rb') as file:
    mass_mat = dill.load(file)
t = symbols("t")
m1 = 1
m2 = 0.2
L = 0.5  # half-length of each legs
rs = 0.8
theta_t_initial = np.deg2rad(10)
theta_s_initial = -theta_t_initial
theta_t_dot_initial = 0
theta_s_dot_initial = 0
g = 9.81
T1 = -1.3
T2 = -T1
inclined_angle = np.deg2rad(0)
plane_len = 1
step = 1/24
time_length = 3
figure_res = [-2, 2]
mass_mat = mass_mat.subs({"m_1": m1, "m_2": m2, "l": L, "g": g, "rs": rs, "alpha": inclined_angle})
equation = equation.subs({"m_1": m1, "m_2": m2, "l": L, "g": g, "rs": rs, "alpha": inclined_angle})
theta_t1 = Function("theta_t")(t)
theta_s1 = Function("theta_s")(t)


def equation1(_, y_):
    theta_t, theta_s, theta_t_dot, theta_s_dot = y_

    Mass_Matrix = mass_mat.subs({theta_t1: y_[0], theta_s1: y_[1]})
    main_equation = equation.subs(
        {theta_t1: y_[0], theta_s1: y_[1], diff(theta_t1, t): y_[2], diff(theta_s1, t): y_[3], "T_1": T1, "T_2": T2})
    inv_mass = Mass_Matrix.inv()
    main_equation = inv_mass @ main_equation
    theta_t_ddot = main_equation[0, 0].evalf()
    theta_s_ddot = main_equation[1, 0].evalf()

    return [theta_t_dot, theta_s_dot, theta_t_ddot, theta_s_ddot]


def terminate_condition1(_, y_):
    if y_[0]+0.001 < y_[1]:

        vertical_y = -(-y_[0] - inclined_angle) * rs * np.sin(inclined_angle) + rs * np.cos(inclined_angle) \
                     + (2 * L - rs) * np.cos(-y_[0]) - (2 * L - rs) * np.cos(y_[1]) - rs * np.cos(inclined_angle)

        horizontal_x = (-y_[0] - inclined_angle) * rs * np.cos(inclined_angle) + rs * np.sin(
            inclined_angle) + (2 * L - rs) * np.sin(-y_[0]) + (2 * L - rs) * np.sin(y_[1]) - rs * np.sin(inclined_angle)
        return vertical_y + horizontal_x * np.tan(inclined_angle)

    else:
        return -1


terminate_condition1.terminal = True
terminate_condition1.direction = -1

sol = solve_ivp(equation1, [0, time_length], [theta_t_initial, theta_s_initial,
                                              theta_t_dot_initial, theta_s_dot_initial], max_step=step,
                events=terminate_condition1)
theta = np.linspace(0, 2 * np.pi, 100)
x = rs * np.cos(theta)
y = rs * np.sin(theta)
print(sol.t[-1])
for i in range(len(sol.t)):
    plt.clf()
    # print(sol.y[2][i],sol.y[3][i])

    # cent of sp
    x_center = (-sol.y[0][i] - inclined_angle) * rs * np.cos(inclined_angle) + rs * np.sin(
        inclined_angle)  # center of sphere
    y_center = -(-sol.y[0][i] - inclined_angle) * rs * np.sin(inclined_angle) + rs * np.cos(inclined_angle)
    x_new = x + x_center
    y_new = y + y_center
    plt.plot(x_new, y_new, "r")

    leg_x, leg_y = (2 * L - rs) * np.sin(-sol.y[0][i]), (2 * L - rs) * np.cos(-sol.y[0][i])

    # sphere 2 leg
    plt.plot([x_center, x_center + leg_x],
             [y_center, y_center + leg_y], "r")
    # leg 2 sphere
    leg_x, leg_y = x_center + leg_x, y_center + leg_y
    plt.plot([leg_x, leg_x + (2 * L - rs) * np.sin(sol.y[1][i])]
             , [leg_y, leg_y - (2 * L - rs) * np.cos(sol.y[1][i])], "b")

    # center of sp
    x_center1 = leg_x + (2 * L - rs) * np.sin(sol.y[1][i])  # center of sphere
    y_center1 = leg_y - (2 * L - rs) * np.cos(sol.y[1][i])
    x_new = x + x_center1
    y_new = y + y_center1
    plt.plot(x_new, y_new, "b")

    plt.plot([0, plane_len * np.cos(inclined_angle)], [0, -plane_len * np.sin(inclined_angle)])
    plt.xlim(figure_res[0], figure_res[1])
    plt.ylim(figure_res[0], figure_res[1])
    plt.show(block=False)
    plt.pause(1/20)
print(np.rad2deg(sol.y[0][-1]),np.rad2deg(sol.y[1][-1]),np.rad2deg(sol.y[2][-1]),np.rad2deg(sol.y[3][-1]))
plt.pause(111)
