import numpy as np
from sympy import *
import dill

with open('combined_eq.dill', 'rb') as file:
    equation = dill.load(file)
with open('single_eq.dill', 'rb') as file:
    test = dill.load(file)

t = symbols("t")
m1 = 1
m2 = 0.2
L = 0.5  # half-length of each legs
rs = 0.8
g = 9.81
inclined_angle = np.deg2rad(0)
plane_len = 1
theta_t = Function("theta_t")(t)
theta_s = Function("theta_s")(t)
equation = equation.subs({"m_1": m1, "m_2": m2, "l": L, "g": g, "rs": rs, "alpha": inclined_angle})
#equation = equation.subs({sin(theta_s-theta_t):theta_s-theta_t-(theta_s-theta_t)**3/6,cos(theta_s-theta_t):1-(theta_s-theta_t)**2/2,sin(theta_s):theta_s-theta_s**3/6,cos(theta_t):1-theta_t**2/2})

theta_t_dot = diff(theta_t, t)
theta_s_dot = diff(theta_s, t)
theta_t_ddot = diff(theta_t, t, 2)
theta_s_ddot = diff(theta_s, t, 2)
theta_t_dddot = diff(theta_t, t, 3)
theta_s_dddot = diff(theta_s, t, 3)
node_num = 8
time_len = 1

h = time_len / node_num
theta_t_sym = []
theta_s_sym = []
theta_t_ddot_fde = []
theta_s_ddot_fde = []
theta_t_dot_fde = []
theta_s_dot_fde = []
eq = []
theta = []
initial_guess = []
for i in range(node_num):
    theta_t_sym.append(symbols(f"theta_t_{i + 1}", real=True))
    theta_s_sym.append(symbols(f"theta_s_{i + 1}", real=True))
for i in range(node_num - 2):
    theta_t_ddot_fde.append((theta_t_sym[i + 2] - 2 * theta_t_sym[i + 1] + theta_t_sym[i]) / h ** 2)
    theta_s_ddot_fde.append((theta_s_sym[i + 2] - 2 * theta_s_sym[i + 1] + theta_s_sym[i]) / h ** 2)
    theta_t_dot_fde.append((theta_t_sym[i + 2] - theta_t_sym[i]) / 2 / h)
    theta_s_dot_fde.append((theta_s_sym[i + 2] - theta_s_sym[i]) / 2 / h)

theta.append(theta_t_sym)
theta.append(theta_s_sym)
theta = [item for sublist in theta for item in sublist]

for i in range(node_num - 2):
    eq.append(equation.subs({theta_t_ddot: theta_t_ddot_fde[i], theta_t_dot: theta_t_dot_fde[i],
                             theta_s_ddot: theta_s_ddot_fde[i], theta_s_dot: theta_s_dot_fde[i]
                                , theta_t: theta_t_sym[i + 1], theta_s: theta_s_sym[i + 1]}))





d_T = expand(diff(test, t))
for i in range(node_num - 4):
    theta_t_dddot_fde = (theta_t_sym[i+4] - 2 * theta_t_sym[i + 3] + 2 * theta_t_sym[i + 1] - theta_t_sym[i]) / 2 / h ** 3
    theta_s_dddot_fde = (theta_s_sym[i+4] - 2 * theta_s_sym[i + 3] + 2 * theta_s_sym[i + 1] - theta_s_sym[i]) / 2 / h ** 3
    eq.append(d_T.subs({theta_t_ddot: theta_t_ddot_fde[i + 1], theta_t_dot: theta_t_dot_fde[i + 1],
                        theta_s_ddot: theta_s_ddot_fde[i + 1], theta_s_dot: theta_s_dot_fde[i + 1]
                           , theta_t: theta_t_sym[i + 2], theta_s: theta_s_sym[i + 2],
                        theta_t_dddot: theta_t_dddot_fde
                           , theta_s_dddot: theta_s_dddot_fde}))
with open('sci_eq.dill', 'wb') as file:
    dill.dump(eq,file)
