import numpy as np
import matplotlib.pyplot as plt
from sympy import *
import dill
from scipy.optimize import root


with open("sci_eq.dill","rb") as file:
    eq = dill.load(file)
g = 9.81
inclined_angle = np.deg2rad(0)
plane_len = 1
t = symbols("t")
m1 = 1
m2 = 0.2
L = 0.5  # half-length of each legs
rs = 0.8
iteration_num = 200
success_list = []


theta_t = Function("theta_t")(t)
theta_s = Function("theta_s")(t)
theta_t_dot = diff(theta_t, t)
theta_s_dot = diff(theta_s, t)
theta_t_ddot = diff(theta_t, t, 2)
theta_s_ddot = diff(theta_s, t, 2)
theta_t_dddot = diff(theta_t, t, 3)
theta_s_dddot = diff(theta_s, t, 3)
for i in range(iteration_num):
    theta_t_initial = np.deg2rad(np.linspace(10, 0, iteration_num)[i])
    theta_s_initial = -theta_t_initial
    for j in range(iteration_num):
        ending_t_ini = np.deg2rad(np.linspace(-10, 0, iteration_num)[j])
        ending_s_ini = -ending_t_ini
        theta_t_dot_initial = -np.random.uniform(0, 1.3)

        theta_s_dot_initial = (abs(theta_t_dot_initial)>1)*(np.random.uniform(0, 0.7))+((abs(theta_t_dot_initial)<1))*np.random.uniform(0.7, 1.3)
        node_num = 8
        time_len = 1
        print(theta_t_initial,ending_t_ini,theta_t_dot_initial,theta_s_dot_initial)
        h = time_len / node_num
        theta_t_sym = []
        theta_s_sym = []
        theta = []
        initial_guess = []
        for i in range(node_num):
            theta_t_sym.append(symbols(f"theta_t_{i + 1}", real=True))
            theta_s_sym.append(symbols(f"theta_s_{i + 1}", real=True))

        theta.append(theta_t_sym)
        theta.append(theta_s_sym)
        theta = [item for sublist in theta for item in sublist]
        BVP1 = theta_t_sym[0] - theta_t_initial
        BVP2 = theta_s_sym[0] - theta_s_initial
        BVP3 = 1 / 12 / h * (
                -25 * theta_t_sym[0] + 48 * theta_t_sym[1] - 36 * theta_t_sym[2] + 16 * theta_t_sym[3] - 3 *
                theta_t_sym[4])-theta_t_dot_initial
        BVP4 = 1 / 12 / h * (
                -25 * theta_s_sym[0] + 48 * theta_s_sym[1] - 36 * theta_s_sym[2] + 16 * theta_s_sym[3] - 3 *
                theta_s_sym[4])-theta_s_dot_initial
        BVP5 = theta_t_sym[-1] - ending_t_ini
        BVP6 = theta_s_sym[-1] - ending_s_ini
        eq.append(BVP1)
        eq.append(BVP2)
        eq.append(BVP3)
        eq.append(BVP4)
        eq.append(BVP5)
        eq.append(BVP6)

        initial_guess.append(np.linspace(theta_t_initial, ending_t_ini, node_num))
        initial_guess.append(np.linspace(theta_s_initial, ending_s_ini, node_num))
        initial_guess = [item for sublist in initial_guess for item in sublist]
        sci_eq = []
        for i in range(len(eq)):
            sci_eq.append(lambdify(theta, eq[i]))
        sci_eq = np.array(sci_eq)
        def fun(x):
            return [func(*x) for func in sci_eq]

        sol = root(fun, initial_guess, method="lm")
        print(sol.success)
        eq=eq[:-6]

        if sol.success:
            success_list.append(1)
        else:
            success_list.append(0)
plt.figure()
success_list = np.array(success_list).reshape(iteration_num, iteration_num)
plt.imshow(success_list, cmap="hot")
plt.colorbar()
plt.xlabel(r'final $\theta_t$ [degree]')
plt.xticks([0,iteration_num-1], [-10,0])
plt.ylabel(r'initial $\theta_t$ [degree]')
plt.yticks([0,iteration_num-1], [10,0])
plt.axis('on')
plt.title("Success-Failure Map")
plt.savefig("success-fail map13")
plt.show()

