import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
from sympy import *
import dill

with open('combined_eq.dill', 'rb') as file:
    equation = dill.load(file)
with open('single_eq.dill', 'rb') as file:
    test = dill.load(file)

t = symbols("t")
m1 = 1
m2 = 0
L = 0.5  # half-length of each legs
rs = 0.6
theta_t_initial = np.deg2rad(0)
theta_s_initial = np.deg2rad(0)
ending_t_ini = np.deg2rad(-15)
ending_s_ini = np.deg2rad(15)
theta_t_dot_initial = 0
theta_s_dot_initial = 0
g = 9.81
inclined_angle = np.deg2rad(0)
plane_len = 1
equation = equation.subs({"m_1": m1, "m_2": m2, "l": L, "g": g, "rs": rs, "alpha": inclined_angle})
test = test.subs({"m_1": m1, "m_2": m2, "l": L, "g": g, "rs": rs, "alpha": inclined_angle})
theta_t = Function("theta_t")(t)
theta_s = Function("theta_s")(t)
theta_t_dot = diff(theta_t, t)
theta_s_dot = diff(theta_s, t)
theta_t_ddot = diff(theta_t, t, 2)
theta_s_ddot = diff(theta_s, t, 2)

h = 0.3
theta_t_1, theta_t_2, theta_t_3, theta_t_4,theta_t_5,theta_t_6, theta_s_1, theta_s_2, theta_s_3, theta_s_4 ,theta_s_5,theta_s_6= symbols(
    'theta_t_1, theta_t_2, theta_t_3, theta_t_4,theta_t_5,theta_t_6, theta_s_1, theta_s_2, theta_s_3, theta_s_4 ,theta_s_5,theta_s_6', real=True)

t_ddot_fde1 = (theta_t_3 - 2 * theta_t_2 + theta_t_1)/ h ** 2
t_ddot_fde2 = (theta_t_4 - 2 * theta_t_3 + theta_t_2)/ h ** 2
t_dot_fde1 = (theta_t_3 - theta_t_1)/2 / h
t_dot_fde2 = (theta_t_4 - theta_t_2)/2 / h


s_ddot_fde1 = (theta_s_3 - 2 * theta_s_2 + theta_s_1)/ h ** 2
s_ddot_fde2 = (theta_s_4 - 2 * theta_s_3 + theta_s_2)/ h ** 2
s_dot_fde1 = (theta_s_3 - theta_s_1)/2 / h
s_dot_fde2 = (theta_s_4 - theta_s_2)/2 / h



eq1 = equation.subs({theta_t_ddot: t_ddot_fde1, theta_t_dot: t_dot_fde1,
                     theta_s_ddot: s_ddot_fde1, theta_s_dot: s_dot_fde1
                        , theta_t: theta_t_2, theta_s: theta_s_2})
eq2 = equation.subs({theta_t_ddot: t_ddot_fde2, theta_t_dot: t_dot_fde2,
                     theta_s_ddot: s_ddot_fde2, theta_s_dot: s_dot_fde2
                        , theta_t: theta_t_3, theta_s: theta_s_3})

BVP1 = theta_t_1 - theta_t_initial
BVP2 = theta_s_1 - theta_s_initial
BVP3 = 1/12/h*(-25*theta_t_1+48*theta_t_2-36*theta_t_3+16*theta_t_4-3*theta_t_5)
BVP4 = 1/12/h*(-25*theta_s_1+48*theta_s_2-36*theta_s_3+16*theta_s_4-3*theta_s_5)

BVP5 = theta_t_6 - ending_t_ini
BVP6 = theta_s_6 - ending_s_ini
sol = nsolve((BVP1, BVP2, BVP3, BVP4, BVP5, BVP6,BVP7,BVP8, eq1, eq2,eq3),
             (theta_t_1, theta_t_2, theta_t_3, theta_t_4,theta_t_5,theta_t_6, theta_s_1, theta_s_2, theta_s_3, theta_s_4 ,theta_s_5,theta_s_6),
             (theta_t_initial, -0, -0,0,0, ending_t_ini, theta_s_initial, 0, 0,0,0, ending_s_ini))


theta_t_1, theta_t_2, theta_t_3, theta_t_4,theta_t_5, theta_s_1, theta_s_2, theta_s_3, theta_s_4 ,theta_s_5 = (i for i in sol)

t_ddot_fde1 = (theta_t_3 - 2 * theta_t_2 + theta_t_1)/ h ** 2
t_ddot_fde2 = (theta_t_4 - 2 * theta_t_3 + theta_t_2) / h ** 2
t_dot_fde1 = (theta_t_3 - theta_t_1)/2 / h
t_dot_fde2 = (theta_t_4 - theta_t_2)/2 / h

s_ddot_fde1 = (theta_s_3 - 2 * theta_s_2 + theta_s_1) / h ** 2
s_ddot_fde2 = (theta_s_4 - 2 * theta_s_3 + theta_s_2) / h ** 2
s_dot_fde1 = (theta_s_3 - theta_s_1)/2 / h
s_dot_fde2 = (theta_s_4 - theta_s_2)/2 / h
T1_1 = test.subs({theta_t_ddot: t_ddot_fde1, theta_t_dot: t_dot_fde1,
                  theta_s_ddot: s_ddot_fde1, theta_s_dot: s_dot_fde1
                     , theta_t: theta_t_2, theta_s: theta_s_2})
T1_2 = test.subs({theta_t_ddot: t_ddot_fde2, theta_t_dot: t_dot_fde2,
                  theta_s_ddot: s_ddot_fde2, theta_s_dot: s_dot_fde2
                     , theta_t: theta_t_3, theta_s: theta_s_3})
print(T1_1, T1_2)
print(theta_t_1, theta_t_2, theta_t_3, theta_t_4,theta_t_5, theta_s_1, theta_s_2, theta_s_3, theta_s_4 ,theta_s_5)