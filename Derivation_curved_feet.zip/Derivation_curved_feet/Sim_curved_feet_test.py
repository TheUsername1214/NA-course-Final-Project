import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
from sympy import *
import dill

with open('equation.dill', 'rb') as file:
    equation = dill.load(file)
with open('Mass_mat.dill', 'rb') as file:
    mass_mat = dill.load(file)
t = symbols("t")
m1 = 1
m2 = 0.2
L = 0.5  # half-length of each legs
rs = 0.8
iteration_num=5
T=[]
ending_angle=[]
for i in range(iteration_num):
    theta_t_initial = np.deg2rad(np.linspace(10, 0, iteration_num)[i])
    starting_anlge = np.deg2rad(np.linspace(10, 0, iteration_num))
    theta_s_initial = -theta_t_initial
    theta_t_dot_initial = 0
    theta_s_dot_initial = 0
    g = 9.81
    T_each_turn=[]
    ending_anlge_each_turn=[]
    for j in range(iteration_num*4):
        T1 = np.linspace(-2, 0, iteration_num*4)[j]
        T2 = -T1
        inclined_angle = np.deg2rad(0)
        plane_len = 1
        step = 0.05
        time_length = 3
        figure_res = [-2, 2]
        mass_mat = mass_mat.subs({"m_1": m1, "m_2": m2, "l": L, "g": g, "rs": rs, "alpha": inclined_angle})
        equation = equation.subs({"m_1": m1, "m_2": m2, "l": L, "g": g, "rs": rs, "alpha": inclined_angle})
        theta_t1 = Function("theta_t")(t)
        theta_s1 = Function("theta_s")(t)


        def equation1(_, y_):
            theta_t, theta_s, theta_t_dot, theta_s_dot = y_

            Mass_Matrix = mass_mat.subs({theta_t1: y_[0], theta_s1: y_[1]})
            main_equation = equation.subs(
                {theta_t1: y_[0], theta_s1: y_[1], diff(theta_t1, t): y_[2], diff(theta_s1, t): y_[3], "T_1": T1, "T_2": T2})
            inv_mass = Mass_Matrix.inv()
            main_equation = inv_mass @ main_equation
            theta_t_ddot = main_equation[0, 0].evalf()
            theta_s_ddot = main_equation[1, 0].evalf()

            return [theta_t_dot, theta_s_dot, theta_t_ddot, theta_s_ddot]


        def terminate_condition1(_, y_):
            if y_[0]+0.001 < y_[1]:

                vertical_y = -(-y_[0] - inclined_angle) * rs * np.sin(inclined_angle) + rs * np.cos(inclined_angle) \
                             + (2 * L - rs) * np.cos(-y_[0]) - (2 * L - rs) * np.cos(y_[1]) - rs * np.cos(inclined_angle)

                horizontal_x = (-y_[0] - inclined_angle) * rs * np.cos(inclined_angle) + rs * np.sin(
                    inclined_angle) + (2 * L - rs) * np.sin(-y_[0]) + (2 * L - rs) * np.sin(y_[1]) - rs * np.sin(inclined_angle)
                return vertical_y + horizontal_x * np.tan(inclined_angle)

            else:
                return -1


        terminate_condition1.terminal = True
        terminate_condition1.direction = -1

        sol = solve_ivp(equation1, [0, time_length], [theta_t_initial, theta_s_initial,
                                                      theta_t_dot_initial, theta_s_dot_initial], max_step=step,
                        events=terminate_condition1)
        theta = np.linspace(0, 2 * np.pi, 100)
        x = rs * np.cos(theta)
        y = rs * np.sin(theta)
        if sol.t[-1] != 3:
                T_each_turn.append(T1)
                ending_anlge_each_turn.append(sol.y[0][-1])
    T.append(T_each_turn)
    ending_angle.append(ending_anlge_each_turn)
with open('T_list.dill', 'wb') as file:
    dill.dump(T,file)
with open('starting_anlge_list.dill', 'wb') as file:
    dill.dump(starting_anlge,file)
with open('ending_angle_list.dill', 'wb') as file:
    dill.dump(ending_angle,file)