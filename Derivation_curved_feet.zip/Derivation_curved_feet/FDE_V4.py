import numpy as np
import matplotlib.pyplot as plt
from sympy import *
import dill
from scipy.optimize import root

with open('combined_eq.dill', 'rb') as file:
    equation = dill.load(file)
with open('single_eq.dill', 'rb') as file:
    test = dill.load(file)
with open("T_list.dill","rb") as file:
    T_list = dill.load(file)
with open("starting_anlge_list.dill","rb") as file:
    starting_angle_list=dill.load(file)
with open("ending_angle_list.dill","rb") as file:
    ending_angle_list=dill.load(file)
t = symbols("t")
m1 = 1
m2 = .2
L = 0.5  # half-length of each legs
rs = 0.8
theta_t_initial = starting_angle_list[0]#np.deg2rad(10)
theta_s_initial = -theta_t_initial#np.deg2rad(-10)
ending_t_ini = ending_angle_list[0][1]#np.deg2rad(-20.43847340468408)
ending_s_ini = -ending_t_ini
theta_t_dot_initial = 0
theta_s_dot_initial = 0
g = 9.81
inclined_angle = np.deg2rad(0)
plane_len = 1
theta_t = Function("theta_t")(t)
theta_s = Function("theta_s")(t)
equation = equation.subs({"m_1": m1, "m_2": m2, "l": L, "g": g, "rs": rs, "alpha": inclined_angle})
# equation = equation.subs({sin(theta_s-theta_t):theta_s-theta_t-(theta_s-theta_t)**3/6,cos(theta_s-theta_t):1-(theta_s-theta_t)**2/2,sin(theta_s):theta_s-theta_s**3/6,cos(theta_t):1-theta_t**2/2})
test = test.subs({"m_1": m1, "m_2": m2, "l": L, "g": g, "rs": rs, "alpha": inclined_angle})

theta_t_dot = diff(theta_t, t)
theta_s_dot = diff(theta_s, t)
theta_t_ddot = diff(theta_t, t, 2)
theta_s_ddot = diff(theta_s, t, 2)
theta_t_dddot = diff(theta_t, t, 3)
theta_s_dddot = diff(theta_s, t, 3)
node_num = 8
time_len = 1

h = time_len / node_num
theta_t_sym = []
theta_s_sym = []
theta_t_ddot_fde = []
theta_s_ddot_fde = []
theta_t_dot_fde = []
theta_s_dot_fde = []
eq = []
theta = []
initial_guess = []
for i in range(node_num):
    theta_t_sym.append(symbols(f"theta_t_{i + 1}", real=True))
    theta_s_sym.append(symbols(f"theta_s_{i + 1}", real=True))
for i in range(node_num - 2):
    theta_t_ddot_fde.append((theta_t_sym[i + 2] - 2 * theta_t_sym[i + 1] + theta_t_sym[i]) / h ** 2)
    theta_s_ddot_fde.append((theta_s_sym[i + 2] - 2 * theta_s_sym[i + 1] + theta_s_sym[i]) / h ** 2)
    theta_t_dot_fde.append((theta_t_sym[i + 2] - theta_t_sym[i]) / 2 / h)
    theta_s_dot_fde.append((theta_s_sym[i + 2] - theta_s_sym[i]) / 2 / h)

theta.append(theta_t_sym)
theta.append(theta_s_sym)
theta = [item for sublist in theta for item in sublist]

for i in range(node_num - 2):
    eq.append(equation.subs({theta_t_ddot: theta_t_ddot_fde[i], theta_t_dot: theta_t_dot_fde[i],
                             theta_s_ddot: theta_s_ddot_fde[i], theta_s_dot: theta_s_dot_fde[i]
                                , theta_t: theta_t_sym[i + 1], theta_s: theta_s_sym[i + 1]}))
BVP1 = theta_t_sym[0] - theta_t_initial
BVP2 = theta_s_sym[0] - theta_s_initial
BVP3 = 1 / 12 / h * (
            -25 * theta_t_sym[0] + 48 * theta_t_sym[1] - 36 * theta_t_sym[2] + 16 * theta_t_sym[3] - 3 * theta_t_sym[4])-theta_t_dot_initial
BVP4 = 1 / 12 / h * (
            -25 * theta_s_sym[0] + 48 * theta_s_sym[1] - 36 * theta_s_sym[2] + 16 * theta_s_sym[3] - 3 * theta_s_sym[4])-theta_s_dot_initial
BVP5 = theta_t_sym[-1] - ending_t_ini
BVP6 = theta_s_sym[-1] - ending_s_ini
eq.append(BVP1)
eq.append(BVP2)
eq.append(BVP3)
eq.append(BVP4)
eq.append(BVP5)
eq.append(BVP6)
d_T = expand(diff(test, t))
for i in range(node_num - 4):
    theta_t_dddot_fde = (theta_t_sym[i+4] - 2 * theta_t_sym[i + 3] + 2 * theta_t_sym[i + 1] - theta_t_sym[i]) / 2 / h ** 3
    theta_s_dddot_fde = (theta_s_sym[i+4] - 2 * theta_s_sym[i + 3] + 2 * theta_s_sym[i + 1] - theta_s_sym[i]) / 2 / h ** 3
    eq.append(d_T.subs({theta_t_ddot: theta_t_ddot_fde[i + 1], theta_t_dot: theta_t_dot_fde[i + 1],
                        theta_s_ddot: theta_s_ddot_fde[i + 1], theta_s_dot: theta_s_dot_fde[i + 1]
                           , theta_t: theta_t_sym[i + 2], theta_s: theta_s_sym[i + 2],
                        theta_t_dddot: theta_t_dddot_fde
                           , theta_s_dddot: theta_s_dddot_fde}))

#
initial_guess.append(np.linspace(theta_t_initial,ending_t_ini,node_num))
initial_guess.append(np.linspace(theta_s_initial,ending_s_ini,node_num))
initial_guess = [item for sublist in initial_guess for item in sublist]
sci_eq = []
for i in range(len(eq)):
    sci_eq.append(lambdify(theta, eq[i]))
sci_eq = np.array(sci_eq)


def fun(x):
    return [func(*x) for func in sci_eq]

sol = root(fun, initial_guess,method="lm")
theta_t_ddot_fde = []
theta_s_ddot_fde = []
theta_t_dot_fde = []
theta_s_dot_fde = []
T=[]
for i in range(node_num - 2):
    theta_t_ddot_fde.append((sol.x[i + 2] - 2 * sol.x[i + 1] + sol.x[i]) / h ** 2)
    theta_s_ddot_fde.append((sol.x[i + 2+node_num] - 2 * sol.x[i + 1+node_num] + sol.x[i+node_num]) / h ** 2)
    theta_t_dot_fde.append((sol.x[i + 2] - sol.x[i]) / 2 / h)
    theta_s_dot_fde.append((sol.x[i + 2+node_num] - sol.x[i+node_num]) / 2 / h)
for i in range(node_num - 2):
    T.append( test.subs({theta_t_ddot: theta_t_ddot_fde[i], theta_t_dot: theta_t_dot_fde[i],
                      theta_s_ddot: theta_s_ddot_fde[i], theta_s_dot: theta_s_dot_fde[i]
                         , theta_t: sol.x[i+1], theta_s: sol.x[i+1+node_num]}))
T=np.array(T)

# DT=expand(diff(test,t))

# for i in range(node_num - 4):
#     print(DT.subs({theta_t_ddot: theta_t_ddot_fde[i+1], theta_t_dot: theta_t_dot_fde[i+1],
#                       theta_s_ddot: theta_s_ddot_fde[i+1], theta_s_dot: theta_s_dot_fde[i+1]
#                          , theta_t: sol.x[i+2], theta_s: sol.x[i+2+node_num],
#                           theta_t_dddot:(sol.x[i+4] - 2 * sol.x[i + 3] + 2 * sol.x[i + 1] - sol.x[i]) / 2 / h ** 3 ,
#                    theta_s_dddot:(sol.x[i+4+node_num] - 2 * sol.x[i + 3+node_num] + 2 * sol.x[i + 1+node_num] - sol.x[i+node_num]) / 2 / h ** 3}))
print(np.rad2deg(sol.x))
print(np.sum(T)/len(T))
print(sol.success)

