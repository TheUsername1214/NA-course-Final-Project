import sympy as sp
from sympy import *
import dill

"""
run this in the jupyter notebook
"""

t, m_1, m_2, g, l, T_1, T_2, rs, alpha = sp.symbols("t,m_1,m_2,g,l,T_1,T_2,rs,alpha")
theta_t = sp.Function("theta_t")(t)
theta_s = sp.Function("theta_s")(t)

touched_leg_x = (-theta_t - alpha) * rs * cos(alpha) + rs * sin(alpha) + (l - rs) * sin(-theta_t)
touched_leg_y = -(-theta_t - alpha) * rs * sin(alpha) + rs * cos(alpha) + (l - rs) * cos(-theta_t)

joint_x = touched_leg_x + l * sin(-theta_t)
joint_y = touched_leg_y + l * cos(-theta_t)

swing_leg_x = joint_x + l * sin(theta_s)
swing_leg_y = joint_y - l * sp.cos(theta_s)

touched_leg_x_dot = sp.diff(touched_leg_x, t)
touched_leg_y_dot = sp.diff(touched_leg_y, t)
joint_x_dot = sp.diff(joint_x, t)
joint_y_dot = sp.diff(joint_y, t)
swing_leg_x_dot = sp.diff(swing_leg_x, t)
swing_leg_y_dot = sp.diff(swing_leg_y, t)

rotation_kinetics = 0.5 * (sp.Rational(1 / 3) * m_1 * l ** 2) * (sp.diff(theta_t, t) ** 2 + sp.diff(theta_s, t) ** 2)
T = rotation_kinetics + 0.5 * m_1 * (touched_leg_x_dot ** 2 + touched_leg_y_dot ** 2
                                     + swing_leg_x_dot ** 2 + swing_leg_y_dot ** 2) + 0.5 * m_2 * (
            joint_x_dot ** 2 + joint_y_dot ** 2)
V = m_1 * g * (touched_leg_y + swing_leg_y) + m_2 * g * joint_y
L = T - V
lagrange1 = simplify(sp.diff(sp.diff(L, sp.diff(theta_t, t)), t) - sp.diff(L, theta_t))
lagrange2 = expand(simplify(sp.diff(sp.diff(L, sp.diff(theta_s, t)), t) - sp.diff(L, theta_s)))

Mass_matrix = sp.Matrix([[0, 0], [0, 0]])
theta_t_ddot = sp.diff(theta_t, t, 2)
theta_s_ddot = sp.diff(theta_s, t, 2)

Mass_matrix[0, 0] = lagrange1.coeff(theta_t_ddot)
Mass_matrix[0, 1] = lagrange1.coeff(theta_s_ddot)
Mass_matrix[1, 0] = lagrange2.coeff(theta_t_ddot)
Mass_matrix[1, 1] = lagrange2.coeff(theta_s_ddot)

Col_matrix = sp.Matrix([[0, 0], [0, 0]])
theta_t_dot = sp.diff(theta_t, t) ** 2
theta_s_dot = sp.diff(theta_s, t) ** 2

Col_matrix[0, 0] = lagrange1.coeff(theta_t_dot)
Col_matrix[0, 1] = lagrange1.coeff(theta_s_dot)
Col_matrix[1, 0] = lagrange2.coeff(theta_t_dot)
Col_matrix[1, 1] = lagrange2.coeff(theta_s_dot)

Gravity_matrix = sp.Matrix([[0], [0]])

Gravity_matrix[0, 0] = lagrange1.subs({theta_t_ddot: 0, theta_s_ddot: 0, theta_t_dot: 0, theta_s_dot: 0})
Gravity_matrix[1, 0] = lagrange2.subs({theta_t_ddot: 0, theta_s_ddot: 0, theta_t_dot: 0, theta_s_dot: 0})
T_matrix = Matrix([[T_1], [T_2]])

equation = -Col_matrix @ Matrix([[sp.diff(theta_t, t) ** 2], [sp.diff(theta_s, t) ** 2]]) \
           - Gravity_matrix + T_matrix

with open('equation.dill', 'wb') as file:
    dill.dump(equation, file)
with open('Mass_mat.dill', 'wb') as file:
    dill.dump(Mass_matrix, file)
FDE_eq = Mass_matrix@Matrix([[theta_t_ddot],[theta_s_ddot]])+Col_matrix @ Matrix([[sp.diff(theta_t, t) ** 2], [sp.diff(theta_s, t) ** 2]]) \
           + Gravity_matrix

with open('combined_eq.dill', 'wb') as file:
    eq = expand(FDE_eq[0]+FDE_eq[1])

    dill.dump(eq, file)
with open('single_eq.dill', 'wb') as file:
    eq = simplify(FDE_eq[0])
    dill.dump(eq, file)